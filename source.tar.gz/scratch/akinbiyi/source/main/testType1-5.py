import matplotlib
matplotlib.use('agg')
import warnings
import numpy as np
import os
import pdb
from multiprocessing import cpu_count
import sys

sys.path[0]=sys.path[0][:-5]

from opPython.setupFolders import *

from simPython.makeSimPedFiles import *
from simPython.genSimZScores import *
from dataPrepPython.genZScores import *
from dataPrepPython.genLZCorr import *

from statsPython.setupELL import *
from statsPython.genELL import*
from statsPython.makeELLMCPVals import*
from statsPython.makeELLMarkovPVals import*
from statsPython.makeGBJPValsSimple import *

from plotPython.plotPower import *
from genPython.makePSD import *

from datetime import datetime
import shutil
import subprocess
import psutil
from distutils.dir_util import copy_tree

import ELL.ell as ell

warnings.simplefilter("error")

local=os.getcwd()+'/'

ellDSet=[.1]
colors=[(1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,0,1),(0,1,1),(.5,.5,.5),(0,.5,0),(.5,0,0),(0,0,.5)]
SnpSize=[4000,4000,300]
traitChr=[18]
snpChr=[snp for snp in range(1,len(SnpSize)+1)]
traitSubset=list(range(1000))

parms={
    'file':sys.argv[0],
    'etaGRM':.5,
    'etaError':.5,
    'ellBetaPpfEps':1e-12,
    'ellKRanLowEps':.1,
    'ellKRanHighEps':1.9,
    'ellKRanNMult':.4,
    'ellDSet':ellDSet,
    'minELLDecForInverse':4,
    'binsPerIndex':700,
    'local':local,
    'numCores':cpu_count(),
    'numPCs':10,
    'snpChr':snpChr,
    'traitChr':traitChr,
    'SnpSize':SnpSize,
    'transOnly':False,
    'colors':colors,
    'RefReps':10000,    
    'maxSnpGen':5000,
    'simLearnType':'Full',
    'response':'hipRaw',
    'quantNormalizeExpr':False,
    'numSnpChr':18,
    'numTraitChr':21,
    'muEpsRange':[],
    'fastlmm':True,
    'fastGrm':False,
    'eyeTrait':True,
    'traitSubset':traitSubset,
    'numSubjects':208*3
}

setupFolders(parms)

DBLog('makeSimPedFiles')
makeSimPedFiles(parms)

DBLog('genZScores')
DBCreateFolder('holds',parms)
genZScores(parms)

DBLog('genLZCorr')
genLZCorr({**parms,'snpChr':[2]})

DBLog('setupELL')
DBCreateFolder('ELL',parms)
setupELL(parms)

DBLog('genELL')
genELL(parms)

DBLog('makeELLMCPVals')
DBCreateFolder('pvals',parms)
makeELLMCPVals(parms)

makeELLMarkovPVals(parms)
pdb.set_trace()
L=np.savetxt('LZCorr/LZCorr',delimiter='\t')
N=len(L)
offDiag=np.matmul(L,L.T)[np.triu_indices(N)]
stat=ell.ell(offDiag,N,np.array([0.1])*N,reportMem=True)

# initialNumLamPoints,finalNumLamPoints, numEllPoints,lamZeta,ellZeta
stat.fit(N*10,N*300,600,7,7)

x=stat.score(np.loadtxt('score/waldStat-3-1',delimiter='\t'))
pMC=stat.monteCarlo(parms['RefReps'],L).reshape(-1,1)
y=np.loadtxt('pvals/ell_0.1_MC-3',delimiter='\t').reshape(-1,1)
z=np.concatenate([pMC,y],axis=1)

pMarkov=stat.markov().reshape(-1,1)
y=np.loadtxt('pvals/ell_0.1_Markov-3',delimiter='\t').reshape(-1,1)
z=np.concatenate([pMarkov,y],axis=1)

pdb.set_trace()
#DBFinish(parms)
