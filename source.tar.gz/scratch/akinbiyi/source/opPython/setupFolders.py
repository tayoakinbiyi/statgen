from opPython.DB import *
import os
import json
import pdb
import subprocess
import numpy as np

def setupFolders(parms,ID=None):
    local=parms['local']

    if ID is None:
        ID=(np.loadtxt(local+'source/ID',delimiter=',').reshape(1)+1).astype(int)
        np.savetxt(local+'source/ID',ID,delimiter=',')
    else:
        ID=np.array([ID])
        
    parms['name']=parms['file']+'-'+str(ID)
    name=parms['name']
    
    if not os.path.exists(local+name):
        os.mkdir(local+name)
        os.chdir(local+name)
        os.mkdir('score')
        os.mkdir('LZCorr')
        os.mkdir('diagnostics')
        os.mkdir('grm')
        os.mkdir('output')
        os.mkdir('pvals')
        os.mkdir('ref')
        os.mkdir('power')
        os.mkdir('stats')
        os.mkdir('holds')
    else:
        os.chdir(local+name)    
    
    DBLogStart(parms)
    DBLog(json.dumps(parms,indent=3))
        
    return(parms)