import numpy as np
from ELL.util import *
import pdb
from multiprocessing import cpu_count

def __init__(self,dList,N,numCores=cpu_count(),reportMem=True,offDiag=None):
    assert np.max(dList)<=.5
    
    self.N=N
    self.dList=(dList*self.N).astype(int)        
    self.reportMem=reportMem
    self.numCores=numCores
    self.nCr=nCr(N)

    if offDiag is None:
        offDiag=np.array([0]*int(N*(N-1)/2))
    
    self.offDiag=offDiag
    self.offDiagMeans=np.array([np.mean(offDiag), np.mean(offDiag**2), np.mean(offDiag**3),
        np.mean(offDiag**4),np.mean(offDiag**5), np.mean(offDiag**6), np.mean(offDiag**7),
        np.mean(offDiag**8),np.mean(offDiag**9), np.mean(offDiag**10)])

    if reportMem:
        memory('init')

    return
