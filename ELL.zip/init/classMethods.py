import numpy as np
from ELL.util import *
import pdb
from multiprocessing import cpu_count

def __init__(self,d,N,numCores=cpu_count(),reportMem=True):
    assert d<=.5*N
    
    self.N=N
    self.nCr=nCr(N)
    self.d=d
    self.reportMem=reportMem
    self.numCores=numCores

    if reportMem:
        memory('init')

    return
