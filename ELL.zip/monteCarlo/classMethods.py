import numpy as np
from ELL.util import memory
from scipy.stats import norm
import pdb

def monteCarlo(self,ref,ell):      
    memory('monteCarlo')
        
    monteCarlo=np.zeros(ell.shape)

    sortOrd=np.argsort(ell,axis=0)
    monteCarlo[sortOrd]=(1+np.searchsorted(np.sort(ref),ell[sortOrd]))/(len(ref)+1)
        
    memory('monteCarlo')

    return(monteCarlo)

