import pdb
import numpy as np
import os
import subprocess

def save(self):
    lamEllByK=self.lamEllByK
    ellGrid=self.ellGrid
    offDiag=self.offDiag
    
    subprocess.call(['mkdir','-p','lamEllByK'])
    
    np.savetxt('lamEllByK/lamEllByK',lamEllByK,delimiter='\t')
    np.savetxt('lamEllByK/ellGrid',ellGrid,delimiter='\t')
    np.savetxt('lamEllByK/offDiag',offDiag,delimiter='\t')
            
    return()

def load(self):
    self.lamEllByK=np.loadtxt('lamEllByK/lamEllByK',delimiter='\t')
    self.ellGrid=np.loadtxt('lamEllByK/ellGrid',delimiter='\t')
    self.offDiag=np.loadtxt('lamEllByK/offDiag',delimiter='\t')
    oLen=len(self.offDiag)
    self.N=int(1/2+np.sqrt(1/4+2*oLen))    

    return()
