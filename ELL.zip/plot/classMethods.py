import matplotlib.pyplot as plt
from zipfile import ZipFile
import pandas as pd
import numpy as np
from scipy.stats import beta
import pdb

def plot(self,pvals,file,qList=[.01,.05],columns=None):
    if columns is None:
        columns=range(pvals.reshape(len(pvals),-1).shape[1])
        legend=False
    else:
        legend=True
        
    colors=[(1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,0,1),(0,1,1),(.5,.5,.5),(0,.5,0),(.5,0,0),(0,0,.5)]
    pvals=pd.DataFrame(np.sort(pvals,axis=0).reshape(len(pvals),-1),columns=columns)    
    
    localLevels=pd.read_csv('../data/local_level_results.csv',header=0,index_col=None).values
    whichEta=np.argmin(np.abs(localLevels[:,0]-pvals.shape[0]))
    eta=localLevels[whichEta,1]
    
    M=len(pvals)
    nVec=np.arange(1,M+1)
    bounds=pd.DataFrame({'lower':beta.ppf(eta/2,nVec,nVec[::-1]),'upper':beta.ppf(1-eta/2,nVec,nVec[::-1])})
    
    pvals.index=np.arange(1,M+1)/(1+M)
    bounds.index=np.arange(1,M+1)/(1+M)

    type1=[]
    ci=['{}({})'.format(q,1.96*np.sqrt(q*(1-q)/m)) for (qL,m) in ((qList,M),) for q in qL]
    for q in qList:
        type1+=[np.mean(pvals.values<q,axis=0).reshape(1,-1)]
    type1+=[np.sum((pvals.T<=bounds['lower'].T)|(pvals.T>=bounds['upper'].T),axis=1).values.reshape(1,-1)>0]
    type1=pd.DataFrame(np.concatenate(type1,axis=0),index=ci+['cross'],columns=columns)
    type1.index.name='alpha'
    type1.to_csv(file+'.tsv',sep='\t')
    
    mMax=max(pvals.index.max(),pvals.max().max())*1.1
    fig, axs = plt.subplots(1,1,dpi=50)   
    fig.set_figwidth(10,forward=True)
    fig.set_figheight(10,forward=True)    
    pvals.plot(ax=axs,legend=legend,xlim=[0,mMax],ylim=[0,mMax],color=colors[0:pvals.shape[1]])
    axs.plot([0,mMax], [0,mMax], ls="--", c=".3")   
    bounds.plot(ax=axs,legend=False,xlim=[0,mMax],ylim=[0,mMax],color='black')
    fig.savefig(file+'-raw.png',bbox_inches='tight')
    
    string='\n'.join(['\t'.join([str(elmt) for elmt in row]) for row in pd.concat([pvals,bounds],axis=1).values.tolist()])
    with ZipFile(file+'-raw.zip','w') as myZip:
        myZip.writestr(file+'-raw.tsv',string) 
      
    logPVals=pvals.copy()
    logBounds=bounds.copy()    
    logPVals.index=-np.log10(pvals.index)
    logPVals.iloc[:]=-np.log10(logPVals.iloc[:])
    logBounds.index=-np.log10(bounds.index)
    logBounds.iloc[:]=-np.log10(logBounds.iloc[:])
        
    mMax=max(logPVals.index.max(),logPVals.max().max())*1.1
    fig, axs = plt.subplots(1,1,dpi=50)   
    fig.set_figwidth(10,forward=True)
    fig.set_figheight(10,forward=True)    
    logPVals.plot(ax=axs,legend=legend,xlim=[0,mMax],ylim=[0,mMax],color=colors[0:logPVals.shape[1]])
    axs.plot([0,mMax], [0,mMax], ls="--", c=".3")   
    logBounds.plot(ax=axs,legend=False,xlim=[0,mMax],ylim=[0,mMax],color='black')
    fig.savefig(file+'-log.png',bbox_inches='tight')
    
    plt.close('all')

    return()