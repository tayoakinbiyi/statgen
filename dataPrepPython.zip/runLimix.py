import pandas as pd
import numpy as np
import subprocess
import pdb
import os
from concurrent.futures import ProcessPoolExecutor, wait, ALL_COMPLETED
from limix.qtl import scan

def runLimix(snps,Y,K,M):
    numSnps=snps.shape[1]
    numTraits=Y.shape[1]
           
    waldStat=np.full([numSnps,numTraits],np.nan)
    eta=np.full([numSnps,numTraits],np.nan)
                        
    with ProcessPoolExecutor() as executor:
        numCores=executor._max_workers
        futures=[]
            
        for core in range(numCores):
            traitRange=np.arange(core*int(np.ceil(numTraits/numCores)),min(numTraits,(core+1)*int(np.ceil(numTraits/numCores))))
            if len(traitRange)==0:
                continue
                
            futures+=[executor.submit(runLimixHelp,Y[:,traitRange],K,M,snps,traitRange)]

        for f in wait(futures,return_when=ALL_COMPLETED)[0]:
            ans=f.result()
            traitRange=ans['trait']                 
            waldStat[:,traitRange]=ans['waldStat']
            eta[:,traitRange]=ans['eta']
        
    return(waldStat,eta)

def runLimixHelp(Y,K,M,snps,traitRange):
    snps=snps.reshape(len(snps),-1)
    waldStat=[]
    eta=[]
    numSnps=snps.shape[1]
        
    for traitInd in np.arange(Y.shape[1]):
        print('{} of {}'.format(traitInd,len(traitRange)),flush=True)
        model=scan(snps, Y[:,traitInd], 'normal', K, M=M,verbose=False)
        ret=model.effsizes['h2']
        waldStat+=[(ret.loc[ret['effect_type']=='candidate','effsize']/ret.loc[
            ret['effect_type']=='candidate','effsize_se']).values.reshape(-1,1)]
        eta+=[np.array([[model._h0._v0/(model._h0._v0+model._h0._v1)]]*numSnps)]
           
    waldStat=np.concatenate(waldStat,axis=1)
    eta=np.concatenate(eta,axis=1)
    
    return({'trait':traitRange,
            'waldStat':waldStat,
            'eta':eta
           })
