import pandas as pd
import numpy as np
import subprocess
import pdb
import os
from limix.model.lmm import LMM
from ELL.util import *
from multiprocessing import cpu_count

def runLimix(Y,QS,M,snps):
    numSnps=snps.shape[1]
    numTraits=Y.shape[1]
           
    b_waldStat=bufCreate('waldStat',[numSnps,numTraits])
    b_waldStat[0][:]=np.nan
    
    b_eta=bufCreate('eta',[numTraits])
    b_eta[0][:]=np.nan

    snpRange=np.arange(numSnps)
    
    pids=[]
    numCores=cpu_count()
    for core in range(numCores):
        traitRange=np.arange(core*int(np.ceil(numTraits/numCores)),min(numTraits,(core+1)*int(np.ceil(numTraits/numCores))))
        if len(traitRange)==0:
            continue
        
        pids+=[remote(runLimixHelp,Y,QS,M,snps,b_waldStat,b_eta,snpRange,traitRange)]

    for pid in pids:
        os.waitpid(0, 0)

    return(bufClose(b_waldStat),bufClose(b_eta))

def runLimixHelp(Y,QS,M,snps,b_waldStat,b_eta,snpRange,traitRange):
    count=0
    
    for trait in traitRange:
        print('{} of {}'.format(count,len(traitRange)),flush=True)
        lmm = LMM(Y[:,trait], M, QS, restricted=False)
        lmm.fit(verbose=False)
        ret=lmm.get_fast_scanner().fast_scan(snps[:,snpRange].reshape(len(snps),-1),False)
        
        b_waldStat[0][snpRange,trait]=ret['effsizes1']/ret['effsizes1_se']
        b_waldStat[1].flush()
        
        b_eta[0][trait]=lmm.v0/(lmm.v0+lmm.v1)
        b_eta[1].flush()
        
        count+=1

    return()