import pandas as pd
import numpy as np
import subprocess
import pdb
import os
from limix.model.lmm import LMM
from ELL.util import *
from multiprocessing import cpu_count
from opPython.utility import *

def runLimix(Y,QS,M,snps):
    numSnps=snps.shape[1]
    numTraits=Y.shape[1]
           
    b_waldStat=bufCreate('waldStat',[numSnps,numTraits])
    b_waldStat[0][:]=np.nan
    
    b_eta=bufCreate('eta',[numTraits])
    b_eta[0][:]=np.nan

    b_bad=bufCreate('bad',[1])
    b_bad[0][0]=0

    pids=[]
    numCores=cpu_count()
    for core in range(numCores):
        traitRange=np.arange(core*int(np.ceil(numTraits/numCores)),min(numTraits,(core+1)*int(np.ceil(numTraits/numCores))))
        if len(traitRange)==0:
            continue
        
        pids+=[remote(runLimixHelp,Y,QS,M,snps,b_waldStat,b_eta,b_bad,traitRange)]

    for pid in pids:
        os.waitpid(0, 0)

    log('runLimix badCount {}'.format(bufClose(b_bad)))
    
    return(bufClose(b_waldStat),bufClose(b_eta))

def runLimixHelp(Y,QS,M,snps,b_waldStat,b_eta,b_bad,traitRange):
    count=1
    badCount=0
    for trait in traitRange:
        print('{} : {} of {}'.format('runLimix',count,len(traitRange)),flush=True)
        lmm = LMM(Y[:,trait], M, QS, restricted=False)
        lmm.fit(verbose=False)
        eta=lmm.v0/(lmm.v0+lmm.v1)
        if eta>.99:
            lmm = LMM(Y[:,trait], M, QS, restricted=True)
            lmm.fit(verbose=False)
            b_bad[0]+=1
            b_bad[1].flush()
            
        ret=lmm.get_fast_scanner().fast_scan(snps,False)
        
        b_waldStat[0][:,trait]=ret['effsizes1']/ret['effsizes1_se']
        b_waldStat[1].flush()
        
        b_eta[0][trait]=lmm.v0/(lmm.v0+lmm.v1)
        b_eta[1].flush()
        
        count+=1

    return()