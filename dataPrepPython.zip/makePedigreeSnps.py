import numpy as np
import pandas as pd
import random
import subprocess
import pdb

def makePedigreeSnps(numSubjects,numSnps,maxSnpGen,pedigreeMult=.1): 
    subprocess.call(['rm','-rf','geneDrop'])
    subprocess.call(['mkdir','-p','geneDrop'])

    subprocess.call(['cp','../ext/sampleIds.txt','geneDrop/sampleIds.txt'])
    pd.DataFrame({'parms':['../ext/ail_revised.ped.txt','geneDrop/sampleIds.txt','geneDrop/map.txt',0,0]}).to_csv(
        'geneDrop/parms.txt',index=False,header=None)
    
    tab=str.maketrans('1234 ','0011.')
    cols=[]
    t_numSnps=0
    while t_numSnps<numSnps:
        newAdd=min(maxSnpGen,numSnps-t_numSnps)
        pd.DataFrame({'# name':np.arange(1,newAdd+1),'length(cM)':1,'spacing(cM)':2,'MAF':.5}).to_csv(
            'geneDrop/map.txt',sep='\t',index=False)

        col=[]
        t_numSubjects=0
        while t_numSubjects<numSubjects:
            cmd=['../ext/gdrop','-p','geneDrop/parms.txt','-s',str(random.randint(1,1e6)),'-o','geneDrop/geneDrop']
            subprocess.run(cmd)
            new=np.loadtxt('geneDrop/geneDrop.geno_true',delimiter='\t',dtype=str)[:,4:].T # subject x snp
            new=new[np.random.choice(np.arange(new.shape[0]),int(new.shape[0]*pedigreeMult),replace=False).astype(int),:]
            new=new.reshape(new.shape[0],-1)
            col+=[new[:(numSubjects-t_numSubjects),:]]
            
            t_numSubjects+=col[-1].shape[0]
          
        col=np.concatenate(col,axis=0)
        col=np.ceil(np.char.translate(col,tab).astype(float))
        af=np.mean(col,axis=0)/2
        maf=np.minimum(af,1-af)
        col=col[:,maf>.1]
        
        cols+=[col]
        t_numSnps+=cols[-1].shape[1]

    snps=np.concatenate(cols,axis=1)
    
    return(snps)