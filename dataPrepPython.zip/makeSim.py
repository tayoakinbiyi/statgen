import pandas as pd
import numpy as np
import pdb
import pyreadr
import subprocess
import random
from scipy.stats import norm

from opPython.makePSD import *
from limix.stats import linear_kinship
from dataPrepPython.makePedigreeSnps import *

def makeSim(parms,genSnps=True,genGrm=True,genY=True,genCov=True):
    print('makeSim')
    
    response=parms['response']
    
    numSubjects=parms['numSubjects']
    numGrmSnps=parms['numGrmSnps']
    numDataSnps=parms['numDataSnps']
    numTraits=parms['numTraits']
    eta=parms['eta']
    
    snpsSeed=parms['snpsSeed']
    grmSeed=parms['grmSeed']
    ySeed=parms['ySeed']
    
    maxSnpGen=parms['maxSnpGen']
    pedigreeMult=parms['pedigreeMult']
    
    yParm=parms['yParm']
    
    if genSnps:
        np.random.seed(snpsSeed)
        np.savetxt('grm',linear_kinship(makePedigreeSnps(numSubjects,numGrmSnps,maxSnpGen,pedigreeMult)),delimiter='\t')
    if genGrm:
        np.random.seed(grmSeed)
        np.savetxt('snps',makePedigreeSnps(numSubjects,numDataSnps,maxSnpGen,pedigreeMult),delimiter='\t')   
    if genY:
        np.random.seed(ySeed)
        if 'depTraits' in yParm:
            LTraitCorr=makePSD(np.corrcoef(pd.read_csv('../data/'+response+'.txt',sep='\t',index_col=0,header=0).values[
                :,0:numTraits],rowvar=False))
        if 'indepTraits' in yParm:
            LTraitCorr=np.eye(numTraits)

        Lgrm=makePSD(np.loadtxt('grm',delimiter='\t'))
        Y=np.sqrt(eta)*np.matmul(np.matmul(Lgrm,norm.rvs(size=[numSubjects,numTraits])),LTraitCorr.T)+np.sqrt(1-eta)*np.matmul(
            norm.rvs(size=[numSubjects,numTraits]),LTraitCorr.T)
        np.savetxt('Y',Y,delimiter='\t')

    if genCov:
        np.savetxt('cov',np.ones([numSubjects,1]),delimiter='\t',fmt='%s')

    return()
