import pandas as pd
import numpy as np
import pdb
import pyreadr
import subprocess
import random
from scipy.stats import norm

from opPython.utility import *
from limix.stats import linear_kinship
from dataPrepPython.makePedigreeSnps import *
from numpy_sugar.linalg import economic_qs

def makeSim(parms):
    print('makeSim')
    
    response=parms['response']
    
    numSubjects=parms['numSubjects']
    numGrmSnps=parms['numGrmSnps']
    numDataSnps=parms['numDataSnps']
    numTraits=parms['numTraits']
    eta=parms['eta']
    
    snpSeed=parms['snpSeed']
    ySeed=parms['ySeed']
    
    maxSnpGen=parms['maxSnpGen']
    pedigreeMult=parms['pedigreeMult']
    
    yParm=parms['yParm']
        
    np.random.seed(snpSeed)
    snps=makePedigreeSnps(numSubjects,numDataSnps,numGrmSnps,maxSnpGen,pedigreeMult)

    grm=linear_kinship(snps['grm'])
    ((Q0, Q1), S0)=economic_qs(grm)
    QS=((Q0, Q1), S0)
    Lgrm=makePSD(grm,'grm')

    np.random.seed(ySeed)
    if 'dep' in yParm:
        LTraitCorr=makePSD(np.corrcoef(pd.read_csv('../data/'+response+'.txt',sep='\t',index_col=0,header=0).values[
            :,0:numTraits],rowvar=False),'LTraitCorr')
    if 'indep' in yParm:
        LTraitCorr=np.eye(numTraits)

    Y=np.sqrt(eta)*np.matmul(np.matmul(Lgrm,norm.rvs(size=[numSubjects,numTraits])),LTraitCorr.T)+np.sqrt(1-eta)*np.matmul(
        norm.rvs(size=[numSubjects,numTraits]),LTraitCorr.T)

    M=np.ones([numSubjects,1])
        
    return(Y,QS,M,snps['data'].reshape(len(snps['data']),-1),Lgrm)
