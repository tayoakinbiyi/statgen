import pandas as pd
import numpy as np
import pdb
import pyreadr
import subprocess
import random
from scipy.stats import norm

from opPython.makePSD import *
from limix.stats import linear_kinship
from dataPrepPython.makePedigreeSnps import *
from numpy_sugar.linalg import economic_qs

def makeSim(parms,fit=True):
    print('makeSim')
    
    response=parms['response']
    
    numSubjects=parms['numSubjects']
    numGrmSnps=parms['numGrmSnps']
    numDataSnps=parms['numDataSnps']
    numTraits=parms['numTraits']
    eta=parms['eta']
    
    snpsSeed=parms['snpsSeed']
    grmSeed=parms['grmSeed']
    ySeed=parms['ySeed']
    
    maxSnpGen=parms['maxSnpGen']
    pedigreeMult=parms['pedigreeMult']
    
    yParm=parms['yParm']
        
    if fit:
        np.random.seed(grmSeed)
        grm=linear_kinship(makePedigreeSnps(numSubjects,numGrmSnps,maxSnpGen,pedigreeMult))
        ((Q0, Q1), S0)=economic_qs(grm)
        np.savetxt('Q0',Q0,delimiter='\t')        
        np.savetxt('Q1',Q1,delimiter='\t')
        np.savetxt('S0',S0,delimiter='\t')
        QS=((Q0, Q1), S0)
        Lgrm=makePSD(grm)
        np.savetxt('Lgrm',Lgrm,delimiter='\t')

        np.random.seed(snpsSeed)
        snps=makePedigreeSnps(numSubjects,numDataSnps,maxSnpGen,pedigreeMult)
        np.savetxt('snps',snps,delimiter='\t') 
        
        np.random.seed(ySeed)
        if 'depTraits' in yParm:
            LTraitCorr=makePSD(np.corrcoef(pd.read_csv('../data/'+response+'.txt',sep='\t',index_col=0,header=0).values[
                :,0:numTraits],rowvar=False))
        if 'indepTraits' in yParm:
            LTraitCorr=np.eye(numTraits)

        Y=np.sqrt(eta)*np.matmul(np.matmul(Lgrm,norm.rvs(size=[numSubjects,numTraits])),LTraitCorr.T)+np.sqrt(1-eta)*np.matmul(
            norm.rvs(size=[numSubjects,numTraits]),LTraitCorr.T)
        np.savetxt('Y',Y,delimiter='\t')

        M=np.ones([numSubjects,1])
        np.savetxt('M',M,delimiter='\t',fmt='%s')

    else:
        Y=np.loadtxt('Y',delimiter='\t')

        Q0=np.loadtxt('Q0',delimiter='\t')
        Q1=np.loadtxt('Q1',delimiter='\t')
        S0=np.loadtxt('S0',delimiter='\t')
        QS=((Q0, Q1), S0)

        M=np.loadtxt('M',delimiter='\t')
        
        snps=np.loadtxt('snps',delimiter='\t')
        
    return(Y,QS,M,snps)
