import pandas as pd
import numpy as np
import pdb
import pyreadr
import subprocess
import random
from scipy.stats import norm

from opPython.utility import *
from limix.stats import linear_kinship
from dataPrepPython.makePedigreeSnps import *
from numpy_sugar.linalg import economic_qs

def makeSim(parms,fit=True):
    print('makeSim')
    
    response=parms['response']
    
    numSubjects=parms['numSubjects']
    numGrmSnps=parms['numGrmSnps']
    numDataSnps=parms['numDataSnps']
    numTraits=parms['numTraits']
    eta=parms['eta']
    
    snpSeed=parms['snpSeed']
    ySeed=parms['ySeed']
    
    maxSnpGen=parms['maxSnpGen']
    pedigreeMult=parms['pedigreeMult']
    
    yParm=parms['yParm']
        
    if fit:
        np.random.seed(snpSeed)
        snps=makePedigreeSnps(numSubjects,numDataSnps,numGrmSnps,maxSnpGen,pedigreeMult)

        grm=linear_kinship(snps['grm'])
        ((Q0, Q1), S0)=economic_qs(grm)
        np.savetxt('Q0',Q0,delimiter='\t')        
        np.savetxt('Q1',Q1,delimiter='\t')
        np.savetxt('S0',S0,delimiter='\t')
        QS=((Q0, Q1), S0)
        Lgrm=makePSD(grm)
        np.savetxt('Lgrm',Lgrm,delimiter='\t')

        np.savetxt('snps',snps['data'],delimiter='\t') 
        
        np.random.seed(ySeed)
        if 'dep' in yParm:
            LTraitCorr=makePSD(np.corrcoef(pd.read_csv('../data/'+response+'.txt',sep='\t',index_col=0,header=0).values[
                :,0:numTraits],rowvar=False))
        if 'indep' in yParm:
            LTraitCorr=np.eye(numTraits)

        Y=np.sqrt(eta)*np.matmul(np.matmul(Lgrm,norm.rvs(size=[numSubjects,numTraits])),LTraitCorr.T)+np.sqrt(1-eta)*np.matmul(
            norm.rvs(size=[numSubjects,numTraits]),LTraitCorr.T)
        np.savetxt('Y',Y,delimiter='\t')

        M=np.ones([numSubjects,1])
        np.savetxt('M',M,delimiter='\t',fmt='%s')

    else:
        Y=np.loadtxt('Y',delimiter='\t')
        Y=Y.reshape(len(Y),-1)

        Q0=np.loadtxt('Q0',delimiter='\t')
        Q0=Q0.reshape(len(Q0),-1)
        Q1=np.loadtxt('Q1',delimiter='\t')
        Q1=Q1.reshape(len(Q1),-1)
        S0=np.loadtxt('S0',delimiter='\t')
        QS=((Q0, Q1), S0)

        M=np.loadtxt('M',delimiter='\t')
        M=M.reshape(len(M),-1)
        
        snps={'data':np.loadtxt('snps',delimiter='\t')}
        
    return(Y,QS,M,snps['data'].reshape(len(snps['data']),-1))
