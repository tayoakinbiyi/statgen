import numpy as np
import pdb
import pandas as pd
from concurrent.futures import ProcessPoolExecutor, wait, ALL_COMPLETED
import subprocess
import time

from dataPrepPython.runLimix import *

def runH1(parms,mu,eps,Z,snps,Y,K,M):     
    numSnps=snps.shape[1]
    numTraits=Y.shape[1]

    waldStat=np.full([numSnps,numTraits],np.nan)
    eta=np.full([numSnps,numTraits],np.nan)
                            
    futures=[]
    ans=[]
    with ProcessPoolExecutor() as executor:
        numCores=executor._max_workers
        for core in range(numCores):
            snpRange=np.arange(core*int(np.ceil(numSnps/numCores)),min(numSnps,(core+1)*int(np.ceil(numSnps/numCores))))
            if len(snpRange)==0:
                continue
            
            futures+=[executor.submit(runH1Help,parms,mu,eps,snps[:,snpRange],Y,K,M,snpRange)]

        for f in wait(futures,return_when=ALL_COMPLETED)[0]:
            ans+=[f.result()]
            print(ans[-1])
                   
    ans=pd.concat(ans,axis=0).sort_values(by=['snp','trait','waldStat'])
    
    Z[ans['snp'],ans['trait']]=ans['waldStat']
    
    return(Z)

def runH1Help(parms,mu,eps,snps,Y0,K,M,snpRange):
    snps=snps.reshape(len(snps),-1)
    
    ans=[]
    for snp in np.arange(len(snpRange)):
        loc=np.random.choice(range(Y0.shape[1]),eps)
        sign=np.random.choice([-1,1],size=eps).reshape(1,-1)
        maf=np.mean(snps[:,snp])/2
        Y=Y0[:,loc]+(mu/np.sqrt(2*eps*maf*(1-maf)))*np.matmul(snps[:,snp].reshape(-1,1),sign)
        ret=runLimixHelp(Y,K,M,snps[:,snp],loc)
        ret=pd.DataFrame({'trait':loc,'waldStat':ret['waldStat'].flatten(),'snp':snpRange[snp]})
        ans+=[ret]
    
    ans=pd.concat(ans,axis=0)
    
    return(ans)
