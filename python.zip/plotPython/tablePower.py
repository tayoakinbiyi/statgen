import matplotlib.pyplot as plt
from zipfile import ZipFile
import pandas as pd
import numpy as np
from scipy.stats import beta, binom
import pdb
from utility import *

def tablePower(pvals,file,cols,qList=np.array([0.01,0.001])):
    path='diagnostics/'+file
    M=len(pvals)

    pvals=pd.DataFrame(np.sort(pvals,axis=0),columns=cols)
    table=np.concatenate([
            np.array([['q','0.025','0.975']+cols]),
            np.concatenate([
                qList.reshape(-1,1),
                np.concatenate([binom.ppf([0.025,0.975],m,q).reshape(1,2)/m for (qL,m) in ((qList,M),) for q in  qL],axis=0)
            ]+[
                np.round(np.mean(x.reshape(-1,1)<qList.reshape(1,-1),axis=0).reshape(-1,1),4) for x in pvals.values.T]
            ,axis=1),
        ],axis=0)
    np.savetxt(path+'-table.tsv',table,delimiter='\t',fmt='%s')
    
    return(table[1,3:].astype(float))