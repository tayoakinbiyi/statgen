import numpy as np
import pdb
import pandas as pd
from concurrent.futures import ProcessPoolExecutor, wait, ALL_COMPLETED
import subprocess
import time

from ELL.util import *
from multiprocessing import cpu_count
from limix.model.lmm import LMM
from numpy_sugar.linalg import economic_qs
from utility import *
def runH1(mu,eps,wald,Y,K,M,snps,eta):     
    numSnps=snps.shape[1]
    numTraits=Y.shape[1]
                            
    b_wald=bufCreate('wald',[numSnps,numTraits])
    b_wald[0][:]=wald
    
    b_eta=bufCreate('eta',[numTraits])
    b_eta[0][:]=eta

    pids=[]
    numCores=cpu_count()
    for core in range(numCores):
        snpRange=np.arange(core*int(np.ceil(numSnps/numCores)),min(numSnps,(core+1)*int(np.ceil(numSnps/numCores))))
        if len(snpRange)==0:
            continue
        
        #runH1Help(mu,eps,Y,K,M,snps,snpRange,b_wald,b_eta)
        pids+=[remote(runH1Help,mu,eps,Y,K,M,snps,snpRange,b_wald,b_eta)]
        
    for pid in pids:
        os.waitpid(0, 0)
        
    return(bufClose(b_wald))

def runH1Help(mu,eps,Y,K,M,snps,snpRange,b_wald,b_eta):
    numSubjects,numTraits=Y.shape
    m=M.shape[1]
    
    for snp in snpRange:
        traitRange=np.random.choice(range(numTraits),eps)
        maf=np.mean(snps[:,snp])/2
        Mhat=np.concatenate([M,snps[:,snp:snp+1]],axis=1)
        count=1
        for trait in traitRange:
            Linv=makeL(b_eta[0][trait]*K+(1-b_eta[0][trait])*np.eye(numSubjects),inv=True)
            g=Linv@snps[:,snp:snp+1]
            g-=np.mean(g)
            
            y=Linv@(Y[:,trait:trait+1]+(mu/np.sqrt(2*eps*maf*(1-maf)))*np.random.choice([-1,1],size=1)*snps[:,snp:snp+1])
            y-=np.mean(y)
            
            b_wald[0][snp,trait]=(g.T@y)/(g.T@g)
            b_wald[1].flush()
            
            count+=1
    
    return()
