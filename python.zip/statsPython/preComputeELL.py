import numpy as np
import pdb
import time
import psutil

import numpy as np
from multiprocessing import cpu_count
from utility import *

from scipy.stats import norm, beta
import sys
import time
import os

import mmap
import subprocess

class preComputeELL:    
    def __init__(self,calD,vZ,numCores=cpu_count()):    
        self.D=vZ.shape[1]
        self.dCr=dCrFunc(vZ.shape[1])
        self.calD=calD
        self.numCores=numCores
        offDiag=vZ[np.triu_indices(vZ.shape[1],1)]   
        self.offDiag=offDiag
        self.offDiagMeans=np.array([np.mean(offDiag), np.mean(offDiag**2), np.mean(offDiag**3),
            np.mean(offDiag**4),np.mean(offDiag**5), np.mean(offDiag**6), np.mean(offDiag**7),
            np.mean(offDiag**8),np.mean(offDiag**9), np.mean(offDiag**10)])
        self.L=makeL(vZ)    

        memory('init')

        return

    def preCompute(self,numLam,minEta):
        t0=time.time()

        numCores=self.numCores
        self.minEta=minEta

        memory('start fit')

        self.minMaxLamPerD(numLam)
        self.minMaxDPerBin()
        self.makePsi()
        
        t1=time.time()

        log('{} : {} min'.format('preCompute',(t1-t0)/60))

        return(bufClose(self.b_psi))

    def minMaxLamPerD(self,numLam,eps=1e-4):    
        calD=self.calD
        D=self.D
        numCores=self.numCores
        offDiagMeans=self.offDiagMeans
        minEta=self.minEta
        dCr=self.dCr
        
        start=findLam(offDiagMeans,0,D,dCr,minEta)[0]
        end=findLam(offDiagMeans,calD-1,D,dCr,1-minEta)[1]
        lam=np.unique(geomBins(numLam,start,end))
        lam=lam[lam>0]
        
        b_minLamPerD=bufCreate('minLamPerD',[calD])
        b_maxLamPerD=bufCreate('maxLamPerD',[calD])
        
        numLam=len(lam)

        pids=[]
        for core in range(numCores):
            dRange=np.arange(core*int(np.ceil(calD/numCores)),min(calD,(core+1)*int(np.ceil(calD/numCores))))
            if len(dRange)==0:
                continue
            
            #minMaxLamPerDHelp(dRange,D,dCr,b_minLamPerD,b_maxLamPerD,minEta,offDiagMeans)
            pids+=[remote(minMaxLamPerDHelp,dRange,D,dCr,b_minLamPerD,b_maxLamPerD,minEta,offDiagMeans)]       

        for pid in pids:
            os.waitpid(0, 0)
            
        self.minLamPerD=bufClose(b_minLamPerD)
        self.maxLamPerD=bufClose(b_maxLamPerD)
        self.lam=lam
        self.numLam=numLam

        memory('minMaxLamPerK')

        return()

    def minMaxDPerBin(self):
        minLamPerD=self.minLamPerD
        maxLamPerD=self.maxLamPerD

        lam=self.lam
        numLam=len(lam)

        minBinPerD=np.clip(np.searchsorted(lam,minLamPerD)-1,0,numLam-1)
        minBinPerD[0]=0

        maxBinPerD=np.clip(np.searchsorted(lam,maxLamPerD),0,numLam-1)

        numLam=np.max(maxBinPerD)+1
        lam=lam[0:numLam]  

        self.minDPerBin=minYPerXFromMaxXPerY(maxXPerY=maxBinPerD,minX=0)
        self.maxDPerBin=maxYPerXFromMinXPerY(minXPerY=minBinPerD,maxX=numLam-1)

        self.minBinPerD=minBinPerD
        self.maxBinPerD=maxBinPerD
        self.lam=lam
        self.numLam=numLam

        memory('minMaxDPerBin')

        return()

    def makePsi(self):
        memory('makePsi')

        numCores=self.numCores
        D=self.D
        maxBin=len(self.lam)
        calD=self.calD
        offDiagMeans=self.offDiagMeans
        lam=self.lam
        dCr=self.dCr
        
        minBinPerD=self.minBinPerD
        maxBinPerD=self.maxBinPerD

        minDPerBin=self.minDPerBin
        maxDPerBin=self.maxDPerBin
        
        psiLen=(maxBinPerD-minBinPerD+1)
        self.b_psi=bufCreate('psi',[np.sum(psiLen),2])
        b_psi=self.b_psi
        numLam=self.numLam
        
        startPsiRowPerD=np.cumsum([0]+psiLen[:-1].tolist())
        self.startPsiRowPerD=startPsiRowPerD
        psiLen=np.sum(psiLen)

        pids=[]
        for core in range(numCores):
            binRange=np.arange(core*int(np.ceil(numLam/numCores)),min(numLam,(core+1)*int(np.ceil(numLam/numCores))))
            if len(binRange)==0:
                continue

            pids+=[remote(makePsiHelp,binRange,D,minDPerBin,maxDPerBin,startPsiRowPerD,b_psi,minBinPerD,
                dCr,lam,offDiagMeans)]
        
        for pid in pids:
            os.waitpid(0, 0)

        memory('makePsi')

        return()

def minMaxLamPerDHelp(dRange,D,dCr,b_minLamPerD,b_maxLamPerD,minEta,offDiagMeans):
    high=1
    low=0
    for dInd in range(len(dRange)):
        lam=findLam(offDiagMeans,dRange[dInd],D,dCr,minEta,low=low,high=high)
        b_minLamPerD[0][dRange[dInd]]=lam[0]
        b_minLamPerD[1].flush()
        low=lam[0]

        lam=findLam(offDiagMeans,dRange[-dInd-1],D,dCr,1-minEta,low=low,high=high)
        b_maxLamPerD[0][dRange[-dInd-1]]=lam[1]
        b_maxLamPerD[1].flush()
        high=lam[1]

    return()

def findLam(offDiagMeans,d,D,dCr,eta,low=0,high=1,eps=0.1):
    lam=[low,high]
    F0=0
    F1=1
    while np.max([np.abs(eta-F0),np.abs(eta-F1)])/np.min([eta,1-eta])>=eps:
        newLam=(lam[1]+lam[0])/2
        newF=F(D,newLam,d,d,dCr,offDiagMeans)[0]
        if newF<eta:
            lam[0]=newLam
            F0=newF
        else:
            lam[1]=newLam
            F1=newF

    return(lam)

def F(D,lam,minK,maxK,dCr,offDiagMeans):
    z=-norm.ppf(lam/2)

    He1 = z**2
    He3 = (z**3-3*z)**2
    He5 = (z**5-10*z**3+15*z)**2
    He7 = (z**7-21*z**5+105*z**3-105*z)**2
    He9 = (z**9-36*z**7+378*z**5-1260*z**3+945*z)**2
    
    odds = ( He1*offDiagMeans[1]/2 + He3*offDiagMeans[3]/24 + He5*offDiagMeans[5]/720 + He7*offDiagMeans[7]/40320 + 
            He9*offDiagMeans[9]/3628800 )
    
    x=4*norm.pdf(z)**2*odds    
    gamma=(x/(lam*(1-lam)-x))
    
    baseOne=np.append([0],np.cumsum(np.log(lam+gamma*np.arange(0,maxK))))
    baseTwo=np.cumsum(np.log(1-lam+gamma*np.arange(D)))[-(maxK+1):][::-1]
    baseThree=np.sum(np.log(1+gamma*np.arange(D)))
    baseCr=dCr[0:(int(maxK)+1)]

    Pr=np.exp(baseCr+baseOne+baseTwo-baseThree)
    
    return(1-np.cumsum(Pr)[minK:maxK+1])


def makePsiHelp(binRange,D,minDPerBin,maxDPerBin,startPsiRowPerD,b_psi,minBinPerD,dCr,lam,offDiagMeans):
    for Bin in binRange:  
        dList=np.arange(minDPerBin[Bin],maxDPerBin[Bin]+1).astype(int)
        fval=F(D,lam[Bin],minDPerBin[Bin],maxDPerBin[Bin],dCr,offDiagMeans)
        loc=startPsiRowPerD[minDPerBin[Bin]:maxDPerBin[Bin]+1]+(Bin-minBinPerD[minDPerBin[Bin]:maxDPerBin[Bin]+1])
        b_psi[0][loc,0]=lam[Bin]+np.arange(minDPerBin[Bin],maxDPerBin[Bin]+1)
        b_psi[0][loc,1]=fval
        b_psi[1].flush()
    
    return()

def minYPerXFromMaxXPerY(maxXPerY,minX):
    maxX=np.max(maxXPerY)
    uniqueMaxXPerY=np.sort(np.unique(maxXPerY))
    minYPer_uniqueMaxXPerY=np.searchsorted(maxXPerY,uniqueMaxXPerY,side='left')
    minYPerX=minYPer_uniqueMaxXPerY[np.searchsorted(uniqueMaxXPerY,np.arange(minX,maxX+1),side='left')].astype(int)
    
    return(minYPerX)

def maxYPerXFromMinXPerY(minXPerY,maxX):
    minX=np.min(minXPerY)
    uniqueMinXPerY=np.sort(np.unique(minXPerY))    
    maxYPer_uniqueMinXPerY=np.searchsorted(minXPerY,uniqueMinXPerY,side='right')-1    
    maxYPerX=maxYPer_uniqueMinXPerY[np.searchsorted(uniqueMinXPerY,np.arange(minX,maxX+1),side='right')-1].astype(int)
    
    return(maxYPerX)

def geomBins(numLam,minVal,maxVal):
    zeta=np.power(minVal/maxVal,1/numLam)
    bins=np.append(np.array([maxVal]),maxVal*np.power(zeta,np.arange(1,numLam+1)))[::-1]
    return(bins)

def dCrFunc(d):
    lFac=np.log(list(range(1,d+1)))
    forw=np.append([0],np.cumsum(lFac))
    bacw=np.append([0],np.cumsum(lFac[::-1]))
    
    return(bacw[0:int(d/2)]-forw[0:int(d/2)])
    