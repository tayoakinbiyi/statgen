import numpy as np
from ELL.util import memory
from scipy.stats import norm
import pdb
import time
from utility import *

def genRef(func,refReps,maxRefReps,vZ,numCores):    
    t0=time.time()
    
    L=makeL(vZ)
    ref=np.ones(refReps)
    numTraits=vZ.shape[1]
    
    t1=time.time()
    
    mins=0
    length=0
    for block in np.arange(int(np.ceil(refReps/maxRefReps))):
        repRange=np.arange(block*maxRefReps,min(refReps,(block+1)*maxRefReps)).astype(int)
        ans,t_mins=func(np.matmul(norm.rvs(size=[len(repRange),numTraits]),L.T),numCores)
        ref[repRange]=ans
        mins+=t_mins
            
    return(ref,(t1-t0)/60+mins)

def mcPVal(test,ref):
    t0=time.time()
    
    refReps=len(ref)

    mc=np.zeros(len(test))
    sortOrd=np.argsort(test)
    mc[sortOrd]=(1+np.searchsorted(np.sort(ref),test[sortOrd]))/(refReps+1)
        
    t1=time.time()
    
    return(mc,(t1-t0)/60)

