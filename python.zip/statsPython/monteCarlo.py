import numpy as np
from ELL.util import memory
from scipy.stats import norm
import pdb
import time
from utility import *
import matplotlib.pyplot as plt

def genRef(func,refReps,maxRefReps,vZ):    
    t0=time.time()
    
    L=makeL(vZ)
    ref=np.ones(refReps)
    numTraits=vZ.shape[1]
    
    t1=time.time()
    
    mins=0
    length=0
    for block in np.arange(int(np.ceil(refReps/maxRefReps))):
        repRange=np.arange(block*maxRefReps,min(refReps,(block+1)*maxRefReps)).astype(int)
        ans,t_mins=func(-np.sort(-np.abs(np.matmul(norm.rvs(size=[len(repRange),numTraits]),L.T))))
        ref[repRange]=ans
        mins+=t_mins
            
    return(ref,(t1-t0)/60+mins)

def mcPVal(test,ref):
    t0=time.time()
    
    refReps=len(ref)

    mc=np.zeros(len(test))
    sortOrd=np.argsort(test)
    mc[sortOrd]=(1+np.searchsorted(np.sort(ref),test[sortOrd]))/(refReps+1)
        
    t1=time.time()
    
    return(mc,(t1-t0)/60)

def mc(func,methodName,refReps,maxRefReps,vZ,dfSet,dfNames):
    ref,mins=genRef(func,refReps,maxRefReps,vZ)
    log('{} : {} min'.format('genRef-'+methodName,mins))

    fig, axs = plt.subplots(1,1,dpi=50)   
    fig.set_figwidth(10,forward=True)
    fig.set_figheight(10,forward=True)  
    axs.hist(ref,bins=60)
    fig.savefig('diagnostics/genRef-'+methodName+'.png')
    
    fig, axs = plt.subplots(1,1,dpi=50)   
    fig.set_figwidth(10,forward=True)
    fig.set_figheight(10,forward=True)  
    axs.hist(-np.log10(ref),bins=60)
    fig.savefig('diagnostics/genRef-log-'+methodName+'.png')

    pvals=[]
    for df in range(len(dfSet)):
        print('beginning score for {} {}'.format(methodName,dfNames[df]),flush=True)
        test,mins=func(dfSet[df])
        log('mc score {} : {} dataset {} min'.format(methodName,dfNames[df],mins))

        print('beginning mcPVal for {} {}'.format(methodName,dfNames[df]),flush=True)
        pval,mins=mcPVal(test,ref)
        log('mc pval {} : {} dataset {} min'.format(methodName,dfNames[df],mins))
        
        pvals+=[pval.reshape(-1,1)]
    
    return(np.concatenate(pvals,axis=1))
 