import numpy as np
from scipy.stats import norm
import pandas as pd
import os

from ELL.util import *
from utility import *
import numpy as np
import pdb
import os
import time

import time

def ELL(psi,wald,numCores):
    t0=time.time()
    
    calD=np.max(psi[:,0].astype(int)+1)
    Reps,numTraits=wald.shape

    b_wald=bufCreate('wald',[Reps,calD])
    b_wald[0][:]=np.sort(2*norm.sf(np.abs(wald)))[:,0:calD]
    
    b_check=bufCreate('check',[3,calD])
    
    b_time=bufCreate('time',[numCores])

    t1=time.time()
            
    pids=[]
    for core in range(numCores):
        repRange=np.arange(core*int(np.ceil(Reps/numCores)),min(Reps,(core+1)*int(np.ceil(Reps/numCores))))
        if len(repRange)==0:
            continue
        scoreHelp(psi,repRange,b_wald,b_check,b_time,core)    
            
        #pids+=[remote(scoreHelp,psi,repRange,b_wald,b_check,b_time,core)]

    for pid in pids:
        os.waitpid(0, 0)
                
    return(bufClose(b_wald)[:,0],((t1-t0)+np.sum(bufClose(b_time)))/60)

def scoreHelp(psi,repRange,b_wald,b_check,b_time,core):   
    t0=time.time()
    
    _,numTraits=b_wald[0].shape
    Reps=len(repRange)

    dLoc=np.array(list(range(numTraits))*Reps)
    
    wald=b_wald[0][repRange].flatten()+dLoc
    
    loc=np.searchsorted(psi[:,0],wald,side='right')
    
    over=np.sum(psi[loc,0].astype(int)>dLoc)
    under=np.sum(psi[loc,0].astype(int)<dLoc)
    
    if over>0:
        log('scoreHelp core {} over {}'.format(core,over))
    if under>0:
        log('scoreHelp core {} under {}'.format(core,under))
       
    b_wald[0][repRange,0]=np.min(psi[loc,1].reshape(Reps,-1),axis=1)
    b_wald[1].flush()
    
    t1=time.time()
    
    b_time[0][core]=(t1-t0)
    b_time[1].flush()
    
    return()
