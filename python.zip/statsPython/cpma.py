import matplotlib.pyplot as plt

import pandas as pd
import numpy as np
import pdb
from multiprocessing import cpu_count
import time
from utility import *
import subprocess
import os
from scipy.stats import norm

def cpma(numCores,z): 
    numSnps,numTraits=z.shape
    
    t0=time.time()
        
    b_time=bufCreate('time',[numCores])
    b_cpma=bufCreate('res',[numSnps])

    t1=time.time()
    
    pids=[]
    for core in range(numCores):
        snpRange=np.arange(core*int(np.ceil(numSnps/numCores)),min(numSnps,(core+1)*int(np.ceil(numSnps/numCores))))
        if len(snpRange)==0:
            continue
        
        pids+=[remote(cpmaHelp,core,snpRange,z,b_time,b_cpma)]
        
    for pid in pids:
        os.waitpid(0, 0)
        
    return(bufClose(b_cpma),(np.sum(bufClose(b_time))+(t1-t0))/60)

def cpmaHelp(core,snpRange,z,b_time,b_cpma):  
    t0=time.time()
    
    N=z.shape[1]
    pi=2*norm.sf(np.abs(z[snpRange]))
    np.savetxt('cpma-'+str(core),pi,delimiter='\t')

    subprocess.call(['Rscript','../source/R/cpma.R','cpma-'+str(core)])
    b_cpma[0][snpRange]=-np.loadtxt('cpma-'+str(core),delimiter='\t')
    b_cpma[1].flush()
    
    t1=time.time()
    
    b_time[0][core]=(t1-t0)
    b_time[1].flush()
        
    return()