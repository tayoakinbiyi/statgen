import numpy as np
from scipy.stats import norm
import pdb
import time
from utility import *
from multiprocessing import cpu_count

def fdr(numCores,wald):
    t0=time.time()
    
    pi=2*norm.sf(np.abs(wald))

    reps=pi.shape[0]
    calD=int(pi.shape[1]*.5)
    D=pi.shape[1]
    
    pids=[]
    b_fdr=bufCreate('fdr',[reps])
    for core in range(numCores):
        repRange=np.arange(core*int(np.ceil(reps/numCores)),min(reps,(core+1)*int(np.ceil(reps/numCores))))

        if len(repRange)==0:
            continue
        
        pids+=[remote(fdrHelp,pi,calD,D,b_fdr,repRange)]

    for pid in pids:
        os.waitpid(0, 0)
        
    ans=bufClose(b_fdr)
    
    t1=time.time()
        
    return(ans,numCores*(t1-t0)/(60))

def fdrHelp(pi,calD,D,b_fdr,repRange):
    b_fdr[0][repRange]=np.min(D*pi[repRange,0:calD]/np.arange(1,calD+1).reshape(1,-1),axis=1)
    b_fdr[1].flush()
    
    return()
