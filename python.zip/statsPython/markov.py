import numpy as np
import pdb
import os

import time
from utility import *
from statsPython.ELL import *
from rpy2.robjects.packages import importr
import rpy2.robjects as ro
import numpy as np
from scipy.stats import norm

def markov(func,wald,lamEllByK,ellGrid,offDiag,numCores):
    t0=time.time()
    memory('markov')
        
    numTraits=wald.shape[1]
    
    stat,mins=func(wald,numCores)
    offDiagVec=ro.FloatVector(tuple(offDiag))
    
    b_markov=bufCreate('markov',wald.shape)
    d=lamEllByK.shape[1]
    
    reps=len(wald)
    
    print('max (grid,stat) ({},{}), min (grid,stat) ({},{})'.format(np.max(ellGrid),np.max(wald),np.min(ellGrid),np.min(wald)))
    
    wald=np.clip(wald,np.min(ellGrid),np.max(ellGrid))
    
    t1=time.time()
    
    pids=[]
    b_markov=bufCreate('markov',[reps])
    for core in range(numCores):
        repRange=np.arange(core*int(np.ceil(reps/numCores)),min(reps,(core+1)*int(np.ceil(reps/numCores))))

        if len(repRange)==0:
            continue
        
        pids+=[remote(markovHelp,repRange,b_markov,stat,lamEllByK,ellGrid,d,numTraits,offDiagVec)]

    for pid in pids:
        os.waitpid(0, 0)
    
    pvals=bufClose(b_markov)

    memory('markov')
    t2=time.time()
    
    log('{} : {} snps, {} min/snp'.format('markov',reps,((t1-t0)+numCores*(t2-t1))/(60*reps)))

    return(pvals)

def markovHelp(repRange,b_markov,stats,lamEllByK,ellGrid,d,N,offDiagVec):    
    gbj=importr('GBJ')
    
    row=np.zeros(N)
    for rep in repRange:
        row[0:d]=-norm.ppf(lamEllByK[np.searchsorted(ellGrid,stats[rep]),0:d]/2)
        row[d:]=row[d-1]

        bounds=ro.FloatVector(row[::-1])
        b_markov[0][rep]=gbj.ebb_crossprob_cor_R(d=N, bounds=bounds, correlations=offDiagVec)[0]
        b_markov[1].flush()
    
    return()