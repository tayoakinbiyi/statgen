import numpy as np
import pdb
import os

import time
from utility import *
from statsPython.ELL import *
from rpy2.robjects.packages import importr
import rpy2.robjects as ro
import numpy as np
from scipy.stats import norm

def markov(func,wald,psi,offDiag,numCores):
    t0=time.time()
    memory('markov')
        
    D=wald.shape[1]
    
    stat,mins=func(wald,numCores)
    offDiagVec=ro.FloatVector(tuple(offDiag))
    
    b_markov=bufCreate('markov',wald.shape)
    calD=np.max(psi['d'])
    
    reps=len(wald)
    
    t1=time.time()

    b_markov=bufCreate('markov',[reps])
    b_z=bufCreate('z',[reps,calD])
    
    pids=[]
    for core in range(numCores):
        dRange=np.arange(core*int(np.ceil(calD/numCores)),min(calD,(core+1)*int(np.ceil(calD/numCores))))

        if len(dRange)==0:
            continue
        #reverseScore(dRange,stat,psi,b_z)
        pids+=[remote(reverseScore,dRange,stat,psi,b_z)]

    for pid in pids:
        os.waitpid(0, 0)
    
    pids=[]
    for core in range(numCores):
        repRange=np.arange(core*int(np.ceil(reps/numCores)),min(reps,(core+1)*int(np.ceil(reps/numCores))))

        if len(repRange)==0:
            continue
        markovHelp(repRange,b_z,b_markov,offDiagVec,calD,D)
        pids+=[remote(markovHelp,repRange,b_z,b_markov,offDiagVec,calD,D)]

    for pid in pids:
        os.waitpid(0, 0)

    pvals=bufClose(b_markov)

    memory('markov')
    t2=time.time()
    
    log('{} : {} snps, {} min/snp'.format('markov',reps,((t1-t0)+numCores*(t2-t1))/(60*reps)))

    return(pvals)

def markovHelp(repRange,b_z,b_markov,offDiagVec,calD,D):
    gbj=importr('GBJ')

    row=np.ones([D])
    for rep in repRange:
        row[0:calD]=b_z[0][rep]
        row[calD:]=row[calD]
        bounds=ro.FloatVector(row[::-1])
        b_markov[0][rep]=gbj.ebb_crossprob_cor_R(d=D, bounds=bounds, correlations=offDiagVec)[0]
        b_markov[1].flush()
    
    return()
    
def reverseScore(dRange,stats,psi,b_z):        
    for d in dRange:
        b_z[0][:,d]=-norm.ppf(psi['lam'][np.searchsorted(psi['eta']+psi['d'],stats+d)]/2)
        b_z[1].flush()

    return()