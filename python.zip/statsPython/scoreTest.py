import numpy as np
from ELL.util import memory
from scipy.stats import norm
import pdb
import time
from utility import *
from multiprocessing import cpu_count
from ELL.util import *

def scoreTest(wald,refReps,maxRefReps,vZ,numCores=cpu_count()):
    ans=monteCarloScoreTestPval(scoreTestScore(wald,numCores),genScoreTestRef(refReps,maxRefReps,vZ,numCores))
    
    return(ans)

def scoreTestScore(wald,numCores):
    t0=time.time()
    memory('scoreTestScore')
    
    reps=wald.shape[0]
    
    pids=[]
    b_score=bufCreate('score',[reps])
    for core in range(numCores):
        repRange=np.arange(core*int(np.ceil(reps/numCores)),min(reps,(core+1)*int(np.ceil(reps/numCores))))

        if len(repRange)==0:
            continue
        
        pids+=[remote(scoreTestScoreHelp,wald[repRange],b_score)]

    for pid in pids:
        os.waitpid(0, 0)
        
    ans=bufClose(b_score)
    
    memory('scoreTestScore')
    t1=time.time()
    
    log('{} : {} snps {} min/snp'.format('scoreTestScore',len(ans),numCores*(t1-t0)/(60)))
    
    return(ans)

def scoreTestScoreHelp(wald,repRange):
    b_score[0][repRange]=np.sum(wald**2,axis=1)
    return()

def genScoreTestRef(refReps,maxRefReps,vZ,numCores):    
    t0=time.time()
    memory('genScoreTestRef')
    
    L=makeL(vZ)
    numTraits=vZ.shape[1]
    
    ref=[]
    for block in np.arange(int(np.ceil(refReps/maxRefReps))):
        reps=int(min(refReps,(block+1)*int(np.ceil(refReps/maxRefReps)))-block*int(np.ceil(refReps/maxRefReps)))
        
        ref+=[scoreTestScore(np.matmul(norm.rvs(size=[reps,numTraits]),L.T),numCores)]
    
    ans=np.concatenate(ref)
    
    memory('genScoreTestRef')
    t1=time.time()
    
    log('{} : {} min'.format('genScoreTestRef',(t1-t0)/(60)))

    return(ans)

def monteCarloScoreTestPval(test,ref):
    t0=time.time()
    memory('monteCarloScoreTestPval')
    
    mc=np.zeros(test.shape)
    refReps=ref.shape[0]

    sortOrd=np.argsort(test,axis=0)
    mc[sortOrd]=1-(1+np.searchsorted(np.sort(ref),test[sortOrd]))/(refReps+2)
        
    memory('monteCarloScoreTestPval')
    t1=time.time()
    
    log('{} : {} min'.format('monteCarloScoreTestPval',(t1-t0)/(60)))

    return(mc)

