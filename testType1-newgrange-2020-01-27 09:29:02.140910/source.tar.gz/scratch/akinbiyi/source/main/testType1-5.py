import matplotlib
matplotlib.use('agg')
import warnings
import numpy as np
import os
import pdb
from multiprocessing import cpu_count
import sys
import ray

local=os.getcwd()+'/'
sys.path=[local+'source']+sys.path

from opPython.setupFolders import *

from simPython.makeSimPedFiles import *
from simPython.genSimZScores import *
from dataPrepPython.genZScores import *
from dataPrepPython.genLZCorr import *

from statsPython.setupELL import *
from statsPython.genELL import*
from statsPython.makeELLMCPVals import*
from statsPython.makeELLMarkovPVals import*
from statsPython.makeGBJPValsSimple import *

from plotPython.plotPower import *
from genPython.makePSD import *

from datetime import datetime
import shutil
import subprocess
import psutil
from distutils.dir_util import copy_tree

import ELL.ell as ell
from ELL.util import memory

warnings.simplefilter("error")

local=os.getcwd()+'/'

ellDSet=[.1]
colors=[(1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,0,1),(0,1,1),(.5,.5,.5),(0,.5,0),(.5,0,0),(0,0,.5)]
SnpSize=[4000,4000,1000]
traitChr=[18,20,19]
snpChr=[snp for snp in range(1,len(SnpSize)+1)]
traitSubset=list(range(1000))

parms={
    'file':sys.argv[0],
    'etaGRM':.5,
    'etaError':.5,
    'ellBetaPpfEps':1e-12,
    'ellKRanLowEps':.1,
    'ellKRanHighEps':1.9,
    'ellKRanNMult':.4,
    'ellDSet':ellDSet,
    'minELLDecForInverse':4,
    'binsPerIndex':700,
    'local':local,
    'numCores':cpu_count(),
    'numPCs':10,
    'snpChr':snpChr,
    'traitChr':traitChr,
    'SnpSize':SnpSize,
    'transOnly':False,
    'colors':colors,
    'RefReps':10000,    
    'maxSnpGen':5000,
    'simLearnType':'Full',
    'response':'hipRaw',
    'quantNormalizeExpr':False,
    'numSnpChr':18,
    'numTraitChr':21,
    'muEpsRange':[],
    'fastlmm':True,
    'grm':2,
    'eyeTrait':True,
    'traitSubset':traitSubset,
    'numSubjects':208*3
}

setupFolders(parms)
'''
DBLog('makeSimPedFiles')
makeSimPedFiles(parms)

DBLog('genZScores')
DBCreateFolder('holds',parms)
genZScores(parms)

DBLog('genLZCorr')
genLZCorr({**parms,'snpChr':[2]})

memory('start')
DBLog('setupELL')
DBCreateFolder('ELL',parms)
setupELL(parms)
memory('setupEll')
DBLog('genELL')
genELL(parms)
memory('genELL')
DBLog('makeELLMCPVals')
DBCreateFolder('pvals',parms)
makeELLMCPVals(parms)
memory('makeELLMCPVals')
makeELLMarkovPVals(parms)
memory('makeELLMarkovPVals')'''
oldScore=np.loadtxt('stats/0.1-3',delimiter='\t').reshape(-1,1)
oldMC=np.loadtxt('pvals/ell_0.1_MC-3',delimiter='\t').reshape(-1,1)
oldMarkov=np.loadtxt('pvals/ell_0.1_Markov-3',delimiter='\t').reshape(-1,1)

L=np.loadtxt('LZCorr/LZCorr',delimiter='\t')
N=L.shape[0]
offDiag=np.matmul(L,L.T)[np.triu_indices(N,1)]
stat=ell.ell(offDiag,N,np.array([0.1])*N,reportMem=True)
stat.fit(N*10,N*700,1000,9,7) # initialNumLamPoints,finalNumLamPoints, numEllPoints,lamZeta,ellZeta
zDat=np.concatenate([np.loadtxt('score/waldStat-3-'+str(x),delimiter='\t') for x in traitChr],axis=1)
newScore=stat.score(zDat).reshape(-1,1)
zScore=np.concatenate([newScore,oldScore],axis=1)
pdb.set_trace()
newMC=stat.monteCarlo(parms['RefReps'],L).reshape(-1,1)
zMC=np.concatenate([newMC,oldMC],axis=1)

newMarkov=stat.markov().reshape(-1,1)
zMarkov=np.concatenate([newMarkov,oldMarkov],axis=1)

pdb.set_trace()
#DBFinish(parms)
