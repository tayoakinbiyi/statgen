import os
import json
import pdb
import subprocess
from zipfile import ZipFile
import pprint
import shutil
import sys
import numpy as np

def setupFolders():
    name=sys.argv[0][:-3]
    
    if not os.path.exists(name):
        os.mkdir(name)
        os.chdir(name)
    else:
        os.chdir(name)    
           
    return()

def diagnostics(mainDef):
    subprocess.call(['rm','-rf','source'])
    subprocess.call(['mkdir','-p','source'])
    sourceFolders=os.listdir('../source')
    
    for folder in [folder for folder in sourceFolders if os.path.isdir('../source/'+folder)]:
        shutil.make_archive('source/'+folder, "zip", '../source/'+folder)

    subprocess.call(['rm','-rf','diagnostics/'])
    subprocess.call(['mkdir','diagnostics'])
    with open('diagnostics/main','w+') as f:
        f.write(mainDef)
    
    return()
       
def git():
    nm='../archive/'
    
    for file in os.listdir('../archive'):
        subprocess.call(['rm','-rf','archive/'+file])

    subprocess.call(['cp','-r','diagnostics/.',nm])  
    subprocess.call(['cp','-r','source/.',nm])  
    
    return()
    
def log(msg): 
    print(msg,flush=True)

    with open('diagnostics/log','a+') as f:
        f.write(pprint.pformat(msg,compact=True)+'\n')
                
    return()

def makePSD(df,corr=True):
    if corr:
        diag=np.diag(1/np.sqrt(np.diag(df)))
        df=np.matmul(np.matmul(diag,df),diag)
    
    U,D,Vt=np.linalg.svd(df)
    if np.min(D)<0:
        print('smallest singular value {}'.format(np.min(D)))
        D-=np.min(D)
    
    L=np.matmul(U,np.diag(np.sqrt(D)))
    
    return(L)