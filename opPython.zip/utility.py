import os
import json
import pdb
import subprocess
from zipfile import ZipFile
import pprint
import shutil
import sys
import numpy as np

from plotPython.myQQ import *

def setupFolders():
    name=sys.argv[0][:-3]
    
    if not os.path.exists(name):
        os.mkdir(name)
        os.chdir(name)
    else:
        os.chdir(name)    
           
    return()

def diagnostics(mainDef):
    subprocess.call(['rm','-rf','source'])
    subprocess.call(['mkdir','-p','source'])
    sourceFolders=os.listdir('../source')
    
    for folder in [folder for folder in sourceFolders if os.path.isdir('../source/'+folder)]:
        shutil.make_archive('source/'+folder, "zip", '../source/'+folder)

    subprocess.call(['rm','-rf','diagnostics/'])
    subprocess.call(['mkdir','diagnostics'])
    with open('diagnostics/'+sys.argv[0],'w+') as f:
        f.write(mainDef)
    
    return()
       
def git():    
    pdb.set_trace()
    for file in os.listdir('../archive'):
        subprocess.call(['rm','-rf','archive/'+file])
    for file in os.listdir('diagnostics'):
        subprocess.call(['cp','-rf','diagnostics/'+file,'../archive'])  
    for file in os.listdir('source'):
        subprocess.call(['cp','-r','source/'+file,'../archive'])  
    subprocess.call(['git','add','*'])
    subprocess.call(['git','commit','-m',sys.argv[0]])
    subprocess.call(['git','push','origin','archive'])
    
    return()
    
def log(msg): 
    print(msg,flush=True)

    with open('diagnostics/log','a+') as f:
        f.write(pprint.pformat(msg,compact=True)+'\n')
                
    return()

def makePSD(df,title):
    U,D,Vt=np.linalg.svd(df)
    log('makePSD {} : {} <0, min is {}'.format(title,np.sum(D<0),np.min(D)))
    if np.min(D)<0:
        D-=np.min(D)
    numTraits=len(D)
    L=np.matmul(U,np.diag(np.sqrt(D)))
    myQQ(df[np.triu_indices(numTraits,1)],np.matmul(L,L.T)[np.triu_indices(numTraits,1)],title,'actual','estimate')
    
    return(L)