import os
import json
import pdb
import subprocess
from zipfile import ZipFile
import pprint
import shutil

def setupFolders(ctrl,ops,mainDef):
    parms={**ctrl,**ops}

    parms['name']=parms['file'][:-3]
    name=parms['name']
    
    if not os.path.exists(name):
        os.mkdir(name)
        os.chdir(name)
    else:
        os.chdir(name)    
           
    diagnostics(mainDef)    
    log(parms)

    return(parms)

def diagnostics(mainDef):
    subprocess.call(['rm','-rf','source'])
    subprocess.call(['mkdir','-p','source'])
    sourceFolders=os.listdir('../source')
    
    for folder in [folder for folder in sourceFolders if os.path.isdir('../source/'+folder)]:
        shutil.make_archive('source/'+folder, "zip", '../source/'+folder)

    subprocess.call(['rm','-rf','diagnostics/'])
    subprocess.call(['mkdir','diagnostics'])
    with open('diagnostics/main','w+') as f:
        f.write(mainDef)
    
    return()
       
def git():
    nm='../archive/'
    
    subprocess.call(['rm','-rf',nm])
    subprocess.call(['cp','-r','diagnostics/.',nm])  
    subprocess.call(['cp','-r','source/.',nm])  
    
    return()
    
def log(msg): 
    print(msg,flush=True)

    with open('diagnostics/log','a+') as f:
        f.write(pprint.pformat(msg,compact=True)+'\n')
                
    return()
